#include <stdio.h>
#include <string.h>

#include "FreeRTOS.h"
#include "queue.h"
#include "semphr.h"
#include "task.h"

#include "event_bus.h"

/* -- Config ------------------------------------------------------------- */
#define MAX_SUBSCRIBERS_PER_TOPIC   6//cbu

/* -- Internal registry -------------------------------------------------- */
typedef struct {
    QueueHandle_t    subscribers[MAX_SUBSCRIBERS_PER_TOPIC];
    uint8_t          count;
    SemaphoreHandle_t lock;
    BusTopicStats_t stats;
} TopicEntry_t;

static TopicEntry_t      s_registry[TOPIC_MAX];
static SemaphoreHandle_t s_dropLock;
static uint32_t          s_dropCount = 0;
static uint32_t          s_nextEventId = 1;

static uint32_t allocateEventId(void)
{
    uint32_t id;
    xSemaphoreTake(s_dropLock, portMAX_DELAY);
    id = s_nextEventId++;
    xSemaphoreGive(s_dropLock);
    return id;
}

static void incrementDropCount(void)
{
    xSemaphoreTake(s_dropLock, portMAX_DELAY);
    s_dropCount++;
    xSemaphoreGive(s_dropLock);
}

/* -- Bus_Init ----------------------------------------------------------- */
void Bus_Init(void)
{
    memset(s_registry, 0, sizeof(s_registry));
    s_dropCount = 0;
    s_nextEventId = 1;
    s_dropLock = xSemaphoreCreateMutex();
    configASSERT(s_dropLock != NULL);

    for (uint8_t i = 0; i < TOPIC_MAX; i++) {
        s_registry[i].lock = xSemaphoreCreateMutex();
        configASSERT(s_registry[i].lock != NULL);
    }

    printf("[BUS] Initialized. %d topics registered with per-topic locks.\n",
           (int)TOPIC_MAX);
}

/* -- Bus_Subscribe ------------------------------------------------------ */
BaseType_t Bus_Subscribe(EventTopic_t topic, QueueHandle_t rxQueue)
{
    configASSERT(topic < TOPIC_MAX);
    configASSERT(rxQueue != NULL);

    TopicEntry_t *entry = &s_registry[topic];

    xSemaphoreTake(entry->lock, portMAX_DELAY);

    if (entry->count >= MAX_SUBSCRIBERS_PER_TOPIC) {
        printf("[BUS] ERROR: subscriber slots full for topic %d\n", topic);
        xSemaphoreGive(entry->lock);
        return pdFAIL;
    }

    entry->subscribers[entry->count++] = rxQueue;
    entry->stats.subscribers = entry->count;
    printf("[BUS] Subscribed to topic %d (slot %d)\n", topic, entry->count - 1);

    xSemaphoreGive(entry->lock);
    return pdPASS;
}

/* -- Bus_Unsubscribe ---------------------------------------------------- */
BaseType_t Bus_Unsubscribe(EventTopic_t topic, QueueHandle_t rxQueue)
{
    configASSERT(topic < TOPIC_MAX);
    configASSERT(rxQueue != NULL);

    TopicEntry_t *entry = &s_registry[topic];
    BaseType_t result = pdFAIL;

    xSemaphoreTake(entry->lock, portMAX_DELAY);

    for (uint8_t i = 0; i < entry->count; i++) {
        if (entry->subscribers[i] == rxQueue) {
            /* Compact the array: shift remaining entries left by one.      */
            /* This preserves dispatch order and leaves no gap.             */
            for (uint8_t j = i; j < (uint8_t)(entry->count - 1U); j++) {
                entry->subscribers[j] = entry->subscribers[j + 1U];
            }
            entry->subscribers[entry->count - 1U] = NULL;
            entry->count--;
            entry->stats.subscribers = entry->count;
            result = pdPASS;
            printf("[BUS] Unsubscribed from topic %d (%u subscribers remain)\n",
                   topic, entry->count);
            break;
        }
    }

    xSemaphoreGive(entry->lock);

    if (result != pdPASS) {
        printf("[BUS] WARN: Bus_Unsubscribe: queue not found on topic %d\n",
               topic);
    }

    return result;
}


BaseType_t Bus_Publish(const Event_t *event)
{
    return Bus_PublishWithCount(event, NULL);//cbu
}

BaseType_t Bus_PublishWithCount(const Event_t *event, uint8_t *sentCount)
{
    configASSERT(event != NULL);
    configASSERT(event->topic < TOPIC_MAX);

    TopicEntry_t *entry = &s_registry[event->topic];
    BaseType_t result = pdPASS;
    uint8_t accepted = 0;
    Event_t routedEvent = *event;

    if (routedEvent.eventId == 0U) {
        routedEvent.eventId = allocateEventId();
    }

    xSemaphoreTake(entry->lock, portMAX_DELAY);
    entry->stats.published++;
    entry->stats.subscribers = entry->count;

    for (uint8_t i = 0; i < entry->count; i++) {
        /* Non-blocking: never stall publisher for a slow subscriber. */
        if (xQueueSend(entry->subscribers[i], &routedEvent, 0) == pdPASS) {
            UBaseType_t depth = uxQueueMessagesWaiting(entry->subscribers[i]);
            accepted++;
            entry->stats.delivered++;
            if (depth > entry->stats.maxQueueDepth) {
                entry->stats.maxQueueDepth = (uint8_t)depth;
            }
        } else {
            incrementDropCount();
            entry->stats.dropped++;
            printf("[BUS] WARN: dropped event topic=%d for subscriber %d "
                   "(total drops=%lu)\n",
                   event->topic, i, (unsigned long)Bus_GetDropCount());
            result = pdFAIL;
        }
    }

    xSemaphoreGive(entry->lock);

    if (sentCount != NULL) {
        *sentCount = accepted;
    }

    return result;
}

/* -- Bus_PublishFromISR ------------------------------------------------- */
BaseType_t Bus_PublishFromISR(const Event_t *event,
                               BaseType_t *pxHigherPriorityTaskWoken)
{
    configASSERT(event != NULL);
    configASSERT(event->topic < TOPIC_MAX);

    TopicEntry_t *entry  = &s_registry[event->topic];
    BaseType_t    result = pdPASS;

    /* ISR path intentionally does not take a mutex. Subscriptions are created
     * before the scheduler starts and remain stable at runtime. */
    entry->stats.published++;
    entry->stats.subscribers = entry->count;

    for (uint8_t i = 0; i < entry->count; i++) {
        if (xQueueSendFromISR(entry->subscribers[i], event,
                              pxHigherPriorityTaskWoken) == pdPASS) {
            entry->stats.delivered++;
        } else {
            s_dropCount++;
            entry->stats.dropped++;
            result = pdFAIL;
        }
    }

    return result;
}

/* -- Bus_GetDropCount --------------------------------------------------- */
uint32_t Bus_GetDropCount(void)
{
    uint32_t count;

    xSemaphoreTake(s_dropLock, portMAX_DELAY);
    count = s_dropCount;
    xSemaphoreGive(s_dropLock);

    return count;
}

uint8_t Bus_GetSubscriberCount(EventTopic_t topic)
{
    configASSERT(topic < TOPIC_MAX);

    TopicEntry_t *entry = &s_registry[topic];
    uint8_t count;

    xSemaphoreTake(entry->lock, portMAX_DELAY);
    count = entry->count;
    xSemaphoreGive(entry->lock);

    return count;
}


BaseType_t Bus_GetTopicStats(EventTopic_t topic, BusTopicStats_t *outStats)
{
    configASSERT(topic < TOPIC_MAX);
    configASSERT(outStats != NULL);

    TopicEntry_t *entry = &s_registry[topic];
    xSemaphoreTake(entry->lock, portMAX_DELAY);
    *outStats = entry->stats;
    xSemaphoreGive(entry->lock);
    return pdPASS;
}
